package Atividade02;

public class DVD extends Midia {
	private int faixas;

	//CONSTRUTOR
	public DVD() {
	}

	public DVD(int codigo, double preco, String nome, int faixas) {
		super(codigo, preco, nome);
		faixas = this.faixas;
	}

	//METODOS
	@Override
	public String getTipo() {
		return "DVD";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Faixas: " + faixas;
	}


	//GETS E SETS
	public int getFaixas() {
		return faixas;
	}

	public void setFaixas(int faixas) {
		faixas = this.faixas;
	}
}
