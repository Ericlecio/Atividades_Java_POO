package Atividade03;

public class MP3 extends Arquivo {
	private int downloads;

	//CONSTRUTOR
	public MP3() {
		// TODO Auto-generated constructor stub
	}

	public MP3(int kbytes, double preco, String autor, int downloads) {
		super(kbytes, preco, autor);
		downloads = this.downloads;
	}

	//METODOS
	@Override
	public String getTipo() {
		return "MP3";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Downloads: " + downloads;
	}

	//GETS E SETS
	public int getDownloads() {
		return downloads;
	}

	public void setDownloads(int downloads) {
		this.downloads = downloads;
	}
}
