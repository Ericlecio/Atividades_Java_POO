package Atividade03;

public class MP4 extends Arquivo {
	private int visitas;

	//CONSTRUTOR
	public MP4() {
		// TODO Auto-generated constructor stub
	}

	public MP4(int kbytes, double preco, String autor, int visitas) {
		super(kbytes, preco, autor);
		visitas = this.visitas;
	}

	//METODOS
	@Override
	public String getTipo() {
		return "MP4";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Visitas: " + visitas;
	}

	//GETS E SETS
	public int getVisitas() {
		return visitas;
	}

	public void setVisitas(int visitas) {
		this.visitas = visitas;
	}
}
