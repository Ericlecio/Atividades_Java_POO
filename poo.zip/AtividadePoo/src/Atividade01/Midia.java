package Atividade01;

public abstract class Midia {
	private int codigo;
	private double preco;
	private String nome;

	//CONSTRUTOR
	public Midia() {
	}

	public Midia(int codigo, double preco, String nome) {
		codigo = this.codigo;
		preco = this.preco;
		nome = this.nome;
	}

	//METODOS
	public String getTipo() {
		return "Midia";
	}

	public String getDetalhes() {
		return "Código: " + codigo + ", Preço: " + preco + ", Nome: " + nome;
	}

	public abstract void printDados();
//	{
//		System.out.println(getTipo() + " - " + getDetalhes());
//	}

	public void inserirDados(int codigo, double preco, String nome) {
		codigo = this.codigo;
		preco = this.preco;
		nome = this.nome;
	}
	
	public void inserirDados1(int codigo, double preco, String nome, int faixas) {
	}
	
	public void inserirDados(int codigo, double preco, String nome, int musicas) {
	}
	
	//GETS E SETS
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	
	
	
}
