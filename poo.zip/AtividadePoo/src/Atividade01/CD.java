package Atividade01;

public class CD extends Midia {
	private int musicas;

	//CONSTRUTOR
	public CD() {
	}

	public CD(int codigo, double preco, String nome, int musicas) {
		super(codigo, preco, nome);
		musicas = this.musicas;
	}

	//METODOS
	@Override
	public String getTipo() {
		return "CD";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Músicas: " + musicas;
	}

	//GETS E SETS
	public void setMusicas(int musicas) {
		musicas = this.musicas;
	}
	
	public int getMusicas() {
		return musicas;
	}
	
	

}
