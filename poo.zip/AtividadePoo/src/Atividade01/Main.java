package Atividade01;

public class Main {
	public static void main(String[] args) {
		//DVD
		DVD dvd = new DVD();
		dvd.setNome("Seila DVD");
		dvd.setPreco(20);
		dvd.setCodigo(11111);
		dvd.setFaixas(20);
		dvd.printDados();

		//CD
//		CD cd = new CD();
//		cd.setNome("seila CD");
//		cd.setPreco(10);
//		cd.setCodigo(22222);
//		cd.setMusicas(50);
//		cd.printDados();
	}
}
