package Atividade01;

public class DVD extends Midia{
	private int faixas;

	//CONSTRUTOR
	public DVD() {
	}

	public DVD(int codigo, double preco, String nome, int faixas) {
		super(codigo, preco, nome);
		this.faixas = faixas;
	}

	//METODOS
	@Override
	public String getTipo() {
		return "DVD";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Faixas: " + this.faixas;
	}
	
	@Override
	public void inserirDados(int codigo, double preco, String nome, int faixas) {
//		super(codigo, preco, nome);
		
		
	}

	//GETS E SETS
	public void setFaixas(int faixas) {
		this.faixas = faixas;
	}

	public int getFaixas() {
		return faixas;
	}

	@Override
	public void printDados() {
		// TODO Auto-generated method stub
		System.out.println(getDetalhes());
	}
}