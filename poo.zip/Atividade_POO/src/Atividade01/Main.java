package Atividade01;

public class Main {
	public static void main(String[] args) {
		DVD dvd = new DVD();
		dvd.inserirDados("Imagine dragons", 1, 30,  2, 0);
		dvd.printDados();	
		
		CD cd = new CD();
		cd.inserirDados("Imagine dragons CD", 1, 25,  5, 0);
		cd.printDados();	
	}
}
