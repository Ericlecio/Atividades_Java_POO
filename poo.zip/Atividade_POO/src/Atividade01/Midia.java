package Atividade01;

public abstract class Midia {
	private int codigo;
	private double preco;
	private String nome;


	//CONSTRUTOR
	public Midia() {
		// TODO Auto-generated constructor stub
	}

	public Midia(int codigo, double preco, String nome) {
		super();
		this.codigo = codigo;
		this.preco = preco;
		this.nome = nome;
	}

	//METODOS
	public String getTipo() {
		return Midia.class.getSimpleName();		
	}

	public String getDetalhes() {
		return Midia.class.getPackageName();		
	}

	abstract void printDados();

	abstract void inserirDados(String nome,int codigo, double preco, int faixas, int musicas);

	//GETS E SETS
	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
}
