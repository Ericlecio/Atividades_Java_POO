package Atividade01;

public class CD extends Midia {
	private int musicas;

	//CONSTRUTOR
	public CD() {
		// TODO Auto-generated constructor stub
	}

	public CD(int musicas) {
		super();
		this.musicas = musicas;
	}

	//METODOS
	@Override
	void printDados() {
		System.out.println("Nome: " + this.getNome());
		System.out.println("Preço: " + this.getPreco());	
		System.out.println("Codigo: " + this.getCodigo());
		System.out.println("Musicas" + this.getMusicas());
		getTipo();
		getDetalhes();
	}

	@Override
	void inserirDados(String nome,int codigo, double preco, int musicas, int faixas ) {
		this.musicas = musicas;	
	}


	//SETS E GETS
	public int getMusicas() {
		return musicas;
	}

	public void setMusicas(int musicas) {
		this.musicas = musicas;
	}
}
