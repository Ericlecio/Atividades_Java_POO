package Atividade01;

public class DVD extends Midia{
	private int faixas;

	//CONSTRUTOR
	public DVD() {
		// TODO Auto-generated constructor stub
	}

	public DVD(int faixas) {
		super();
		this.faixas = faixas;
	}

	//METODOS
	@Override
	void printDados() {
		System.out.println("Nome: " + this.getNome());
		System.out.println("Preço: " + this.getPreco());	
		System.out.println("Codigo: " + this.getCodigo());	
		System.out.println("Faixa: " + this.getFaixas());
		getTipo();
		getDetalhes();
	}
	
	@Override
	void inserirDados(String nome,int codigo, double preco, int faixas, int musicas) {
		this.faixas = faixas;
	}


	//SETS E GETS
	public int getFaixas() {
		return faixas;
	}

	public void setFaixas(int faixas) {
	}

	
}