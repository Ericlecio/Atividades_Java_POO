package Atividade02;
import java.util.Random;

public class Midia {
	private int codigo;
	private double preco;
	private String nome;

	public Midia() {
	}

	public Midia(int c, double p, String n) {
		codigo = c;
		preco = p;
		nome = n;
	}

	public String getTipo() {
		return "Midia";
	}

	public String getDetalhes() {
		return "Código: " + codigo + ", Preço: " + preco + ", Nome: " + nome;
	}

	public void printDados() {
		System.out.println(getTipo() + " - " + getDetalhes());
	}

	public void inserirDados(int c, double p, String n) {
		codigo = c;
		preco = p;
		nome = n;
	}
}
