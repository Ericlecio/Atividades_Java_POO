package Atividade02;

public class CD extends Midia {
	private int musicas;

	public CD() {
	}

	public CD(int c, double p, String n, int m) {
		super(c, p, n);
		musicas = m;
	}

	@Override
	public String getTipo() {
		return "CD";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Músicas: " + musicas;
	}

	public void setMusicas(int m) {
		musicas = m;
	}
}
