package Atividade02;

import java.util.Random;

public class Main {
	public static void main(String[] args) {
		Random random = new Random();
		int choice = random.nextInt(2); // Gera 0 ou 1 aleatoriamente

		Midia midia;

		if (choice == 0) {
			int codigo = random.nextInt(1000);
			double preco = random.nextDouble() * 100;
			String nome = "CD Example";
			int musicas = random.nextInt(20);
			midia = new CD(codigo, preco, nome, musicas);
		} else {
			int codigo = random.nextInt(1000);
			double preco = random.nextDouble() * 100;
			String nome = "DVD Example";
			int faixas = random.nextInt(30);
			midia = new DVD(codigo, preco, nome, faixas);
		}

		midia.printDados();
	}
}
