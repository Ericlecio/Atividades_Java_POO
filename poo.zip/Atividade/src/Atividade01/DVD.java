package Atividade01;

public class DVD extends Midia{
	private int faixas;

	public DVD() {
	}

	public DVD(int c, double p, String n, int f) {
		super(c, p, n);
		faixas = f;
	}

	@Override
	public String getTipo() {
		return "DVD";
	}

	@Override
	public String getDetalhes() {
		return super.getDetalhes() + ", Faixas: " + faixas;
	}

	public void setFaixas(int f) {
		faixas = f;
	}
}