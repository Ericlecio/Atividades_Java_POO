package Atividade01;

public class Main {
	public static void main(String[] args) {
		DVD dvd = new DVD(1, 19.99, "DVD Example", 12);
		CD cd = new CD(2, 9.99, "CD Example", 15);

		dvd.printDados();
		cd.printDados();
	}
}
